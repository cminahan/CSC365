import java.sql.*;
import java.util.Scanner;

public class InnReservations {
    static String jdbcUrl = System.getenv("HP_JDBC_URL");
    static String dbUsername = System.getenv("HP_JDBC_USER");
    static String dbPassword = System.getenv("HP_JDBC_PW");

    public static void main(String[] args) {
        try (Connection conn = DriverManager.getConnection(jdbcUrl, dbUsername, dbPassword); ) {
            conn.setAutoCommit(false);

            Statement stmt = conn.createStatement();

            // delete lab7_reservations table
            boolean delete_reservations = stmt.execute("DROP TABLE IF EXISTS lab7_reservations;");

            // delete lab7_rooms table
            boolean delete_rooms = stmt.execute("DROP TABLE IF EXISTS lab7_rooms;");

            // create lab7_rooms table
            boolean lab7_rooms = stmt.execute("CREATE TABLE IF NOT EXISTS lab7_rooms" + 
                                            "(RoomCode char(5) PRIMARY KEY, " + 
                                            "RoomName varchar(30) NOT NULL, " +
                                            "Beds int(11) NOT NULL, " + 
                                            "bedType varchar(8) NOT NULL, " + 
                                            "maxOcc int(11) NOT NULL, " + 
                                            "basePrice DECIMAL(6, 2) NOT NULL, " + 
                                            "decor varchar(20) NOT NULL, " + 
                                            "UNIQUE (Roomname));");

            // create lab7_reservations table
            boolean lab7_reservations = stmt.execute("CREATE TABLE IF NOT EXISTS lab7_reservations" +
                                                   "(CODE int(11) PRIMARY KEY, " +
                                                   "Room char(5) NOT NULL, " +
                                                   "CheckIn date NOT NULL, " +
                                                   "Checkout date NOT NULL, " +
                                                   "Rate DECIMAL(6,2) NOT NULL, " +
                                                   "LastName varchar(15) NOT NULL, " +
                                                   "FirstName varchar(15) NOT NULL, " + 
                                                   "Adults int(11) NOT NULL, " +
                                                   "Kids int(11) NOT NULL, " +
                                                   "FOREIGN KEY (Room) REFERENCES lab7_rooms (RoomCode));");
            
            // populate lab7_rooms table
            int populate_rooms = stmt.executeUpdate("INSERT INTO lab7_rooms SELECT * FROM INN.rooms;");

            // populate lab7_reservations table
            // DATE_ADD shifts reservation dates to current year
            int populate_dates = stmt.executeUpdate("INSERT INTO lab7_reservations SELECT CODE, Room, " +
                                                "DATE_ADD(CheckIn, INTERVAL 134 MONTH), " +
                                                "DATE_ADD(Checkout, INTERVAL 134 MONTH), " +
                                                "Rate, LastName, FirstName, Adults, Kids FROM INN.reservations;");

            Scanner in = new Scanner(System.in);
            
            // print out prompt
            prompt();

            // prompt the user for their search instruction
            System.out.print("Enter the number of the search instruction: ");
            
            // read in the user's input
            String s = in.nextLine();
            int i = Integer.parseInt(s);

            while (i != 7) {
                doTheWork(i, in);
            }

            in.close();
            conn.commit();
        } catch (SQLException e) {
            e.printStackTrace();
        } 
    }

    public static void prompt() {
        System.out.println("[1]: Rooms and Rates");
        System.out.println("[2]: Reservations");
        System.out.println("[3]: Reservation Change");
        System.out.println("[4]: Reservation Cancellation");
        System.out.println("[5]: Detailed Reservation Information");
        System.out.println("[6]: Revenue");
        System.out.println("[7]: Quit");
    }

    public static void doTheWork(int s, Scanner in) {
        try (Connection conn = DriverManager.getConnection(jdbcUrl, dbUsername, dbPassword); ) {
            conn.setAutoCommit(false);

            Statement stmt = conn.createStatement();

        int rescode = 1;

        // done
        if (s == 1) {
            boolean operation = stmt.execute("WITH popularity_scores AS " +
                                                "(SELECT Room, SUM(DATEDIFF(Checkout, CheckIn)) / 180 AS PopularityScore " +
                                                "FROM lab7_reservations " +
                                                "WHERE CheckIn >= DATE_SUB(CURDATE(), INTERVAL 180 DAY) " +
                                                "GROUP BY Room), " +
                                                "next_available AS ( " +
                                                "SELECT Room, MAX(Checkout) AS NextAvailable " +
                                                "FROM lab7_reservations " +
                                                "GROUP BY Room), " +
                                                "recent_stay AS ( " +
                                                "SELECT Room, DATEDIFF(Checkout, CheckIn) AS RecentStay " +
                                                "FROM lab7_reservations " +
                                                "WHERE (Room, CheckOut) IN ( " +
                                                "SELECT * FROM next_available);" +
                                                "SELECT popularity_scores.Room, next_available.NextAvailable, recent_stay.RecentStay " +
                                                "FROM popularity_scores " + 
                                                "INNER JOIN next_available ON popularity_scores.Room = next_available.Room " +
                                                "INNER JOIN recent_stay ON next_available.Room = recent_stay.Room;");
        }
        //figure out how to get the 5 and then get their result from it
        else if (s == 2) {
            while (true) {
                System.out.print("Please enter Firstname, Lastname, Roomcode ('Any' if no preference), Bedtype ('Any' if no preference)," +
                                "Checkin date, Checkout date, Number of Children, Number of Adults: ");
                String input = in.nextLine();
                String pref[] = input.split(",");
                String roomcode = "";
                String bedtype = "";
                if (pref[2] != "Any") {
                    roomcode = "and RoomCode = " + pref[2];
                }
                if (pref[3] != "Any") {
                    bedtype = "and bedType = " + pref[3];
                }
                ResultSet rs = stmt.executeQuery("select * from lab7_rooms" + 
                                                    "where roomcode not in " + 
                                                    "(select roomcode from lab7_rooms" + 
                                                    "join lab7_reservations on roomcode = room" +
                                                    "where checkin <= " + pref[5] + "and checkout >= " + pref[4] + ")" + 
                                                    "where maxOcc >= " + (pref[6] + pref[7]) + roomcode + bedtype +
                                                    "limit 5");
                                                    
                int count = 1;
                String[][] availrooms = null;
                while (rs.next()) {
                    String newroomcode = rs.getString("RoomCode");
                    String roomname = rs.getString("RoomName");
                    String beds = rs.getString("Beds");
                    String newbedtype = rs.getString("bedType");
                    String maxocc = rs.getString("maxOcc");
                    String baseprice = rs.getString("basePrice");
                    String decor = rs.getString("decor");

                    System.out.format("%s: %s %s %s %s %s %s %s", count, newroomcode, roomname, beds, newbedtype, maxocc, baseprice, decor);
                    
                    String room[] = {rs.getString("CODE"), newroomcode, pref[5], pref[6], rs.getString("Rate")};
                    
                    availrooms[count - 1] = room;
                    count = count + 1;

                }

                System.out.print("Which one would you like to reserve? (Enter option number): ");
                int roomchoice = Integer.parseInt(in.nextLine()) - 1;
                if (availrooms != null) {
                    int operation = stmt.executeUpdate("insert into lab7_reservations" +
                                                "(code, room, checkin, checkout, rate, lastname, firstname, adults, kids) " + 
                                                "values( " + rescode + ", " + availrooms[roomchoice - 1][1] + ", " + pref[4] + ", " +
                                                pref[5] + ", " + availrooms[roomchoice - 1][4] + ", " + pref[1] + ", " + pref[0] + ", " +
                                                pref[6] + ", " + pref[7] + ");");
                    rescode = rescode + 1;
                    break;
                }
                else {
                    System.out.print("No rooms available. Please enter new parameters.");
                }
            }
        }


        //check if reservation is okay to change
        else if (s == 3) {
            System.out.print("Please enter reservation code: ");
            String code = in.nextLine();
            System.out.print("What would you like to change? (Firstname, Lastname, CheckIn, Checkout, Kids, Adults)" + 
                            "And what would you like to change it to, separated by comma? (ex: Firstname, John)");
            String change[] = in.nextLine().split(",");
            ResultSet rs_reservations = stmt.executeQuery("select Room, Adults, Kids from lab7_reservations where CODE = " + code);
            String RoomCode = rs_reservations.getString("Room");
            if (change[0] == "Firstname" or change[0] == "Lastname") {
                boolean operation = stmt.execute("update lab7_reservations " + 
                                                "set " + change[0] + " = " + change[1] + 
                                                "where code = " + "code;");
            }
            else if (change[0] == "Kids" or change[0] == "Adults") {
                int adults = rs_reservations.getString("Adults");
                int kids = rs_reservations.getString("Kids");
        
                ResultSet rs = stmt.executeQuery("select maxOcc from lab7_rooms where roomcode = " + RoomCode + ";");
                int maxocc = rs.getInt("maxOcc");
                if (change[0] = "Kids") {
                    int numocc = Integer.parseInt(change[1]) + adults;
                } else {
                    int numocc = Integer.parseInt(change[1]) + kids;
                }
                if (numocc > maxocc) {
                    System.out.println("Unable to change reservation, max occupancy reached for room");
                } else {
                    int update_guests = stmt.executeUpdate("update lab7_reservations" +
                                                            "set " + change[0] + " = " + change[1] +
                                                            "where CODE = " + code + ";");
                }
            }

            else if (change[0] == "CheckIn" or change[0] == "Checkout") {
                if (change[0] == "Checkin") {
                    ResultSet rs = stmt.executeQuery("select * from lab7_reservations where RoomCode = " + roomcode +
                                            "and CheckIn <= " + change[1] + "and Checkout >= " + change[1] + "and CODE <> " + code);
                }
                else {
                    ResultSet rs = stmt.executeQuery("select * from lab7_reservations where RoomCode = " + roomcode +
                                            "and Checkin <= " + change[1] + " and CODE <> " + code + ";");
                }
                if (rs == null) {
                    int update_guests = stmt.executeUpdate("update lab7_reservations" +
                                                            "set " + change[0] + " = " + change[1] +
                                                            "where CODE = " + code + ";");
                } else {
                    System.out.println("Unable to change reservation, " + change[0] + " date collides with other reservation.")
                }
            }                
        }
        //done
        else if (s == 4) {
            System.out.print("Enter reservation code you with to delete: ");
            String code = in.nextLine();
            boolean operation = stmt.execute("delete from lab7_reservations " + "where CODE = " + code);
        }
        //done
        else if (s == 5) {
            System.out.print("Please enter 'firstname', 'lastname', 'daterange', 'roomcode', or 'code': ");
            String input = in.nextLine();
            System.out.print("Please enter the " + input + " you're looking for (if daterange separate with comma): ");
            String type = in.nextLine();
            if (input == "daterange") {
                String dates[] = type.split(",");
                boolean operation = stmt.execute("select * from lab7_reservations where " + 
                                                    dates[0] + " <= checkout and checkin <= " + dates[1]);
            }
            else {
                boolean operation = stmt.execute("select * from lab7_reservations where " + input + "= '" + type + "';");
            }
        }
        //done
        else if (s == 6) {
            boolean operation = stmt.execute("with jan_rev as" + 
                                                "(select Room, abs(sum(datediff(greates(CheckIn, '2021-01-01'), least(Checkout, '2021-01-31')) * Rate)) as Revenue " + 
                                                "from lab7_reservations " + 
                                                "where month(CheckIn) <= 1 and month(Checkout) >= 1 " + 
                                                "group by Room), " + 
                                                
                                                "feb_rev as" + 
                                                "(select Room, abs(sum(datediff(greates(CheckIn, '2021-02-01'), least(Checkout, '2021-02-28')) * Rate)) as Revenue " + 
                                                "from lab7_reservations " + 
                                                "where month(CheckIn) <= 2 and month(Checkout) >= 2 " + 
                                                "group by Room), " +
                                                
                                                "mar_rev as" + 
                                                "(select Room, abs(sum(datediff(greates(CheckIn, '2021-03-01'), least(Checkout, '2021-03-31')) * Rate)) as Revenue " + 
                                                "from lab7_reservations " + 
                                                "where month(CheckIn) <= 3 and month(Checkout) >= 3 " + 
                                                "group by Room), " +
                                                
                                                "apr_rev as" + 
                                                "(select Room, abs(sum(datediff(greates(CheckIn, '2021-04-01'), least(Checkout, '2021-04-30')) * Rate)) as Revenue " + 
                                                "from lab7_reservations " + 
                                                "where month(CheckIn) <= 4 and month(Checkout) >= 4 " + 
                                                "group by Room), " +
                                                
                                                "may_rev as" + 
                                                "(select Room, abs(sum(datediff(greates(CheckIn, '2021-0-501'), least(Checkout, '2021-05-31')) * Rate)) as Revenue " + 
                                                "from lab7_reservations " + 
                                                "where month(CheckIn) <= 5 and month(Checkout) >= 5 " + 
                                                "group by Room), " +
                                                
                                                "jun_rev as" + 
                                                "(select Room, abs(sum(datediff(greates(CheckIn, '2021-06-01'), least(Checkout, '2021-06-30')) * Rate)) as Revenue " + 
                                                "from lab7_reservations " + 
                                                "where month(CheckIn) <= 6 and month(Checkout) >= 6 " + 
                                                "group by Room), " +
                                                
                                                "jul_rev as" + 
                                                "(select Room, abs(sum(datediff(greates(CheckIn, '2021-07-01'), least(Checkout, '2021-07-31')) * Rate)) as Revenue " + 
                                                "from lab7_reservations " + 
                                                "where month(CheckIn) <= 7 and month(Checkout) >= 7 " + 
                                                "group by Room), " +
                                                
                                                "aug_rev as" + 
                                                "(select Room, abs(sum(datediff(greates(CheckIn, '2021-08-01'), least(Checkout, '2021-08-31')) * Rate)) as Revenue " + 
                                                "from lab7_reservations " + 
                                                "where month(CheckIn) <= 8 and month(Checkout) >= 8 " + 
                                                "group by Room), " +
                                                
                                                "sept_rev as" + 
                                                "(select Room, abs(sum(datediff(greates(CheckIn, '2021-09-01'), least(Checkout, '2021-09-30')) * Rate)) as Revenue " + 
                                                "from lab7_reservations " + 
                                                "where month(CheckIn) <= 9 and month(Checkout) >= 9 " + 
                                                "group by Room), " +
                                                
                                                "oct_rev as" + 
                                                "(select Room, abs(sum(datediff(greates(CheckIn, '2021-10-01'), least(Checkout, '2021-10-31')) * Rate)) as Revenue " + 
                                                "from lab7_reservations " + 
                                                "where month(CheckIn) <= 10 and month(Checkout) >= 10 " + 
                                                "group by Room), " +
                                                
                                                "nov_rev as" + 
                                                "(select Room, abs(sum(datediff(greates(CheckIn, '2021-11-01'), least(Checkout, '2021-11-30')) * Rate)) as Revenue " + 
                                                "from lab7_reservations " + 
                                                "where month(CheckIn) <= 11 and month(Checkout) >= 11 " + 
                                                "group by Room), " +
                                                
                                                "dec_rev as" + 
                                                "(select Room, abs(sum(datediff(greates(CheckIn, '2021-12-01'), least(Checkout, '2021-12-31')) * Rate)) as Revenue " + 
                                                "from lab7_reservations " + 
                                                "where month(CheckIn) <= 12 and month(Checkout) >= 12 " + 
                                                "group by Room), " +
                                                
                                                "monthly_revs as " + 
                                                "(select distinct Room, " + 
                                                "if((lab7_reservations.Room) in (select Room from jan_rev), (select Revenue from jan_rev where Room = lab7_reservations.Room, 0) as JanRev, " + 
                                                "if((lab7_reservations.Room) in (select Room from feb_rev), (select Revenue from feb_rev where Room = lab7_reservations.Room, 0) as FebRev, " +
                                                "if((lab7_reservations.Room) in (select Room from mar_rev), (select Revenue from mar_rev where Room = lab7_reservations.Room, 0) as MarRev, " +
                                                "if((lab7_reservations.Room) in (select Room from apr_rev), (select Revenue from apr_rev where Room = lab7_reservations.Room, 0) as AprRev, " +
                                                "if((lab7_reservations.Room) in (select Room from may_rev), (select Revenue from may_rev where Room = lab7_reservations.Room, 0) as MayRev, " +
                                                "if((lab7_reservations.Room) in (select Room from jun_rev), (select Revenue from jun_rev where Room = lab7_reservations.Room, 0) as JunRev, " +
                                                "if((lab7_reservations.Room) in (select Room from jul_rev), (select Revenue from jul_rev where Room = lab7_reservations.Room, 0) as JulRev, " +
                                                "if((lab7_reservations.Room) in (select Room from aug_rev), (select Revenue from aug_rev where Room = lab7_reservations.Room, 0) as AugRev, " +
                                                "if((lab7_reservations.Room) in (select Room from sept_rev), (select Revenue from sept_rev where Room = lab7_reservations.Room, 0) as SeptRev, " +
                                                "if((lab7_reservations.Room) in (select Room from oct_rev), (select Revenue from oct_rev where Room = lab7_reservations.Room, 0) as OctRev, " +
                                                "if((lab7_reservations.Room) in (select Room from nov_rev), (select Revenue from nov_rev where Room = lab7_reservations.Room, 0) as NovRev, " +
                                                "if((lab7_reservations.Room) in (select Room from dec_rev), (select Revenue from dec_rev where Room = lab7_reservations.Room, 0) as DecRev " +
                                                "from lab7_reservations)" + 
                                                
                                                "select Room, JanRev, FebRev, MarRev, AprRev, MayRev, JunRev, JulRev, AugRev, SeptRev, OctRev, " + 
                                                    "NovRev, DecRev, (JanRev + FebRev + MarRev + AprRev + MayRev + JunRev + JulRev + AugRev + " +
                                                    "SeptRev + OctRev + NovRev + DecRev) as TotalRev " +
                                                "from monthly_revs");
        }
        conn.commit();
    } catch (SQLException e) {
        e.printStackTrace();
    } 
    }
}